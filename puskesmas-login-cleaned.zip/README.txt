Aplikasi Login Puskesmas (PHP + MySQL)

- index.php: Form login
- dashboard.php: Halaman setelah login
- logout.php: Logout user
- includes/db.php: Koneksi ke database
- includes/auth.php: Fungsi autentikasi
- database/puskesmas.sql: Struktur & data user
- style/style.css: Gaya halaman

Default user: admin / admin123