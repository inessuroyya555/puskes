CREATE DATABASE IF NOT EXISTS puskesmas_db;
USE puskesmas_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL
);

INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'Administrator'),
('dinkes', 'dinkes2025', 'Dinas Kesehatan'),
('puskesmas1', 'puskesmas123', 'Operator'),
('lnessuroyya', '123456', 'User'),
('demo', 'demo', 'Demo User');